<!-- <div class="row">
    <div class="col-md-10">
        <div class="card1">
            <div class="card-body">
                <div class="row ">
                    <div class="col-md-5">

                        <h2>Welcome, <?php echo $this->session->userdata('un');?>!,<br><span> consectetur adipisicing elit</span></h2>
                        <p class="mb-3"> Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                            sed do eiusmod
                            tempor incididunt ut labore et.</p>
                    </div>
                    <div class="col-md-7">
                        <div class="row">
                            <div class="col-lg-12 col-xl-6">
                                <a href="" data-toggle="modal" data-target="#newSurveyBank">
                                    <div class="card">
                                        <div class="card-body box">
                                            <div class="img11">
                                                <img src="<?php echo base_url() ?>assets/img/plan.png" alt="">
                                            </div>
                                            <h2>Create Survey</h2>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> -->


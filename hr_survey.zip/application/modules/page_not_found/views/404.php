<!-- begin::Body -->
<body  class="m--skin- m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--fixed m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default"  >
    <div class="m-grid__item m-grid__item--fluid m-grid  m-error-2" style="background-image: url(<?php echo base_url('assets/app/media/img/error/bg2.jpg');?>);">
        <div class="m-error_container">
            <span class="m-error_title2 m--font-light">
                 <h1>OOPS!</h1>		 
             </span> 	
            <span class="m-error_desc m--font-light">
                 Something went wrong here
            </span>		 
         </div>	 
    </div>

</body>
      





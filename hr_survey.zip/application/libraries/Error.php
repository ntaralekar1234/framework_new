<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Error 
{
	public function add()
	{
		return "Record add succefully";
	}

}
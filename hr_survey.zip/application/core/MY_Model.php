<?php
/**
* gefines generic crud functionality for database operation (CRUD)
*/
class MY_Model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	
	
}